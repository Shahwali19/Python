
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Registration</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
	include_once("config.php");

    // If form submitted, insert values into the database.
    if (isset($_REQUEST['userid'])){
		$userid = stripslashes($_REQUEST['userid']); // removes backslashes
		$email = stripslashes($_REQUEST['email']);
		$password = stripslashes($_REQUEST['password']);


		
        $query = "INSERT into `users` (userid, email, password) VALUES ('$userid', '$email' '".md5($email)."')";
        $result = mysqli_query($mysqli,$query);
        if($result){
            echo "<div class='form'><h3>You are registered successfully.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
        }
    }
?>

