<?php
/*
Author: Javed Ur Rehman
Website: http://www.allphptricks.com/
*/
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
	include_once("config.php");

	session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['MT'])){
		
		$MT = stripslashes($_REQUEST['MT']); // removes backslashes
		$email = stripslashes($_REQUEST['email']);
		
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `users` WHERE MT='$MT' and email='".md5($email)."'";
		$result = mysqli_query($con,$query) or die(mysql_error());
		$rows = mysqli_num_rows($result);
        if($rows==1){
			$_SESSION['MT'] = $MT;
			header("Location: index.php"); // Redirect user to index.php
            }else{
				echo "<div class='form'><h3>MT/email is incorrect.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
				}
    }else{
?>
<div class="form">
<h1>Log In</h1>
<form action="" method="post" name="login">
<input type="text" name="MT" placeholder="MT" required />
<input type="email" name="email" placeholder="email" required />
<input name="submit" type="submit" value="Login" />
</form>
<p>Not registered yet? <a href='registration.php'>Register Here</a></p>

<br /><br />

</div>
<?php } ?>


</body>
</html>
