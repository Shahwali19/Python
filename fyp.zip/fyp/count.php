








<html>
<head>
     <link rel="stylesheet" type="text/css" href="add.css">

	<title></title>
</head>

<body>
<?php
//including the database connection file

$server = "localhost";
$username = "root";
$password = "";
$database = "fyptwo";
$mysqli = mysqli_connect($server, $username, $password, $database); 



$sql = "SELECT count(id) AS total FROM users"; //where sex='female';
$result = mysqli_query($mysqli,$sql);
$values = mysqli_fetch_assoc($result);
$num_rows=$values['total'];
echo 'The total number of user is' . $num_rows;

?>
</body>
</html>
